#include "mainwidget.h"
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>

MainWidget::MainWidget(QWidget *parent) :  QWidget(parent)
{
    // Create two buttons and a text field
    QVBoxLayout* layout=new QVBoxLayout(this);
        QHBoxLayout* buttonsBox=new QHBoxLayout();
            QPushButton* startButton=new QPushButton("Start",this);
            buttonsBox->addWidget(startButton);
            QPushButton* quitButton=new QPushButton("Quit",this);
            buttonsBox->addWidget(quitButton);
        layout->addLayout(buttonsBox);
        text=new QTextEdit(this);
        text->setTextInteractionFlags(Qt::NoTextInteraction);
        layout->addWidget(text);

    // Connect signals of the buttons
    connect(startButton, SIGNAL(clicked()), this, SLOT(runTest()));
    connect(quitButton,  SIGNAL(clicked()), this, SLOT(close()));

    // List paired devices
    if (rfcomm.isEnabled()) {
        text->append("Known devices:");
        QMap<QString,QString> map=rfcomm.getKnownDevices();
        QMapIterator<QString,QString> iterator(map);
        while (iterator.hasNext()) {
            iterator.next();
            QString label=QString("%1=%2").arg(iterator.key()).arg(iterator.value());
            text->append(label);
        }
    }
    else {
        text->append("The interface is disabled");
    }
}

void MainWidget::runTest() {
    qDebug("Start button clicked");

    QString deviceName("HC-06");
    text->append(QString("Start testing %1").arg(deviceName));

    // Connect and communicate
    rfcomm.connect(deviceName);
    if (rfcomm.isConnected()) {
        text->append("Connected");

        // Now send two commands and display the response.
        // The commands are specific for the device that is attached to the bluetooth adapter.
        {
            // Send command
            char cmd[]="oPA3,0";
            text->append(QString("sending: %1").arg(cmd));
            rfcomm.sendLine(cmd);

            // Receive the answer
            QString response=rfcomm.receiveLine(200);
            text->append(QString("received: %1").arg(response));
        }

        {
            // Send another command
            char cmd[]="oPA4,0";
            text->append(QString("sending: %1").arg(cmd));
            rfcomm.sendLine(cmd);

            // Receive the answer
            QString response=rfcomm.receiveLine(200);
            text->append(QString("received: %1").arg(response));
        }

        rfcomm.disconnect();
    }
    else {
        text->append("Cannot connect");
    }

    text->append("Test finished");
}
