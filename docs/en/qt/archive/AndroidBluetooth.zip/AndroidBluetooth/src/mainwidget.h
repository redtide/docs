#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include "androidrfcomm.h"
#include <QWidget>
#include <QTextEdit>

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MainWidget(QWidget *parent = 0);

private slots:
    void runTest();

private:
    AndroidRfComm rfcomm;
    QTextEdit* text;
};

#endif // MAINWIDGET_H
