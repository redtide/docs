﻿/**
  @file
  @author Stefan Frings
  Pusblished for free use without any warranties.
*/

#ifndef ANDROIDRFCOMM_H
#define ANDROIDRFCOMM_H

#include <QMap>
#include <QString>
#include <QRegExp>
#include <QByteArray>
#include <QAndroidJniObject>
#include <QAndroidJniEnvironment>

/**
 * RFCOMM connector for Android.
 * This class allows you to communicate with a Bluetooth device via RFCOMM protocol (SPP profile).
 * <p>
 * It calls the Java API of the Android OS, since there is no native API for bluetooth available.
 * <p>
 * The class does not provide a feature to pair devices. The user may do that manually in the
 * system settings of the Android OS. Once a device is paired, you can communicate with it.
 * <p>
 * Your project file must contain
 * QT += androidextras
 * <p>
 * Your android.xml file must contain
 * <uses-permission android:name="android.permission.BLUETOOTH"/>
 */

class AndroidRfComm  {
    Q_DISABLE_COPY(AndroidRfComm)

public:

    /** Whether to encode text as latin1 instead of UTF-8, default is UTF-8. */
    bool useLatin1;

    /** Terminator for sending lines of text, default is a Unix line break. */
    QString sendTerminator;

    /** Terminator for receiving lines of text, default is a Dos or Unix line break */
    QRegExp receiveTerminator;

    /** Maximum number of bytes in the read buffer. This also limits the maximum length of text lines. Default is 1024. */
    int readBufferSize;

    /** UUID of bluetooth service, needed to connect, default is "00001101-0000-1000-8000-00805F9B34FB" */
    QString uuid;

    /**
     * Constructor.
     */
    AndroidRfComm();

    /**
     * Destructor, disconnects if not already disconnected.
     */
    ~AndroidRfComm();

    /**
     * Check whether the Bluetooth interface of the Android device is enabled.
     * @return true if Bluetooth is enabled.
     */
    bool isEnabled();

    /**
     * Get a list of all paired remote devices with address and descriptive name.
     * The user can add additional devices in the "settings" of his Android device.
     * @return A map with the device address as key and name as value.
     */
    QMap<QString,QString> getKnownDevices();

    /**
     * Open a connection to a remote device.
     * @param name Name or address of the device, e.g. "HC-06" or "20:13:11:15:16:08" as returned by getKnownDevices().
     * @see isConnected() to check for success.
     */
    void connect(const QString& name);

    /**
     * Check if the android device is connected to the remote device.
     * @return true if the connection is open.
     */
    bool isConnected();


    /**
     * Close the connection.
     */
    void disconnect();

    /**
     * Send raw data to the remote device.
     * @param data An array of bytes
     */
    void send(const QByteArray& data);

    /**
     * Send a line of text to the remote device.
     * @param text line of text to send. The terminator (line-break) gets appended automatically.
     */
    void sendLine(const QString& text);

    /**
     * Query how many bytes have been received and can be read out now.
     * @return Number of bytes that are available for reading.
     */
    int available();

    /**
     * Receive a number of bytes from the remote device.
     * This method blocks until either the requested number of bytes have been received or
     * the maximum time is reached.
     * In case of a timeout, it returns the bytes that have been received so far.
     * @param maxNumOfBytes Number of bytes that are expected.
     * @param waitMilliSeconds Maximum allowed time to wait for the number of bytes.
     * @return The received bytes.
     */
    QByteArray receive(const int maxNumOfBytes, const int waitMilliSeconds);

    /**
     * Receive a line of text from the remote device.
     * This method blocks until either a line of text has been received or the maximum time is reached.
     * In case of a timeout, it returns the bytes that have been received so far.
     * @param waitMilliSeconds Maximum allowed time to wait for the line.
     * @return The received line of text, without terminator.
     */
    QString receiveLine(const int waitMilliSeconds);

    /**
     * Check whether the previous receive() or receiveLine() call ran into a timeout.
     * @return true if a timeout occured.
     */
    bool hasTimeout();

protected:

    /** Indicator whether a previous call to receive() or receiveLine() ran into a timeout */
    bool timeout;

    /** Buffer for received bytes */
    QByteArray buffer;

    /** JNI Environment */
    QAndroidJniEnvironment env;

    /** Reference to Java object android.bluetooth.BluetoothAdapter */
    QAndroidJniObject adapter;

    /** Reference to Java object android.bluetooth.BluetoothDevice */
    QAndroidJniObject device;

    /** Reference to Java object android.bluetooth.BluetoothSocket */
    QAndroidJniObject socket;

    /** Reference to Java object java.io.InputStream */
    QAndroidJniObject istream;

    /** Reference to Java object java.io.OutputStream */
    QAndroidJniObject ostream;

    /**
     * Read data from the device into the buffer filed of this object.
     * @return The number of bytes read.
     */
    int readIntoBuffer();

    /**
     * Check for and log Java exception.
     */
    void check(const char* method);

    /**
     * Check for and log Java exception, also check if a Java object is valid.
     */
    void check(const char* method, const QAndroidJniObject& obj);
};

#endif // ANDROIDRFCOMM_H
